import numpy as np
import sys
import Camera
from equations3D import Equations
import pygame
from Room_vib3D import Room
import Integrators
from Integrators import exp_midpoint
from Camera import makeVideo
class Simulation:
    def __init__(self, num_particles, num_steps, alpha, A, w, fai, room_size, method = "exp_midpoint", tau = 0.0023):

        self.L = room_size                              # size of square room (m)
        self.N = num_particles                          # quantity of particles
        self.tau = tau                                  # time-step (s)
        self.num_steps = num_steps                      # number of steps for integration
        self.A = A
        self.w = w
        self.alpha = alpha
        self.fai = fai
        # Particle information
        self.radii = 0.001 * 2 * np.ones(self.N)        # radii of particles (m)
        self.m = 0.001 * 0.06 * np.ones(self.N)          # mass of particles (kg)
        self.v_0 = np.zeros(self.N)                     # desired velocity (m/s)
        self.forces = None                              # forces on the particles
        self.v = np.zeros((3, self.N, self.num_steps))  # Three dimensional array of velocity
        self.y = np.zeros((3, self.N, self.num_steps))  # Three dimensional array of place: x = coordinates(0:x, 1:y, 2:z), y = particle, z = Time
        
        # other
        self.room = Room(self.L, self.alpha, self.A, self.w, self.fai, self.num_steps, tau)  # kind of room the simulation runs in
        self.method = getattr(Integrators, method)  # method used for integration
        self.equ = Equations(self.N, self.L, self.tau, self.room, self.radii, self.m, self.alpha, self.num_steps)  # initialize Differential equation
 
    # function set_time, set_steps give the possiblity to late change these variable when needed
    def set_steps(self, steps):
        self.num_steps = steps

    # function to change the methode of integration if needed
    def set_methode(self, method):
        self.method = getattr(Integrators, method)

    def dont_touch(self, i, pos):  # yields false if particles don't touch each other and true if they do
        for j in range(i - 1):
            if np.linalg.norm(np.array(pos) - self.y[:, j, 0]) < 5 * self.radii[i]:
                return True
        return False

    # fills the spawn zone with particles with random positions
    def fill_room(self):
        print("正在初始化颗粒位置……")
        spawn = self.room.get_spawn_zone()
        length = spawn[1] - spawn[0]

        # checks if the area is too small for the particles to fit in
        volume_particle = 0
        for i in range(self.N):
            volume_particle += 4 * self.radii[i] ** 3 / 3
        if volume_particle >= 0.5 * self.room.get_room_size() ** 3:
            sys.exit('Too much particles! ')

        # checks if the particle touches another particle/wall and if so gives it a new random position in the spawn-zone 
        for i in range(self.N):
            # The particle don't touch the wall
            x = length * np.random.rand() + spawn[0]
            y = self.room.get_room_size() - ( x * np.tan(self.room.get_alpha()) + 1.5 * self.radii[i])
            z = length * np.random.rand() + spawn[0]
            pos = [x, y, z]

            # The particle don't touch each other
            while self.dont_touch(i, pos):  #touch is true, change x,y coordinate
                x = length * np.random.rand() + spawn[0]
                y = self.room.get_room_size() - ( x * np.tan(self.room.get_alpha()) + 1.5 * self.radii[i])
                z = length * np.random.rand() + spawn[0]
                pos = [x, y, z]
            self.y[:, i, 0] = pos

        self.v[:, :, 0] = self.v_0
        print("颗粒位置初始化完成")

    # calls the method of integration with the starting positions, diffequatial equation, number of steps, and delta t = tau
    def run(self):
        print("正在模拟……")
        self.y, self.forces = self.method(self.y[:, :, 0], self.v[:, :, 0], self.equ.f, self.num_steps, self.tau, self.room)
        print("模拟完成")

    def show(self, sim_size, fps):
        print("正在加载结果……")
        makeVideo(self.y, self.room, sim_size, fps)
