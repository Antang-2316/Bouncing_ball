import moviepy.editor as mpy
import numpy as np
import mayavi.mlab as mlab
import os

def turn1(ary, l):
	z1 = ary[2]			#ary : shape(3,)
	x1 = - ary[1]+l
	y1 = ary[0]
	return np.array([x1,y1,z1])

def turn2(ary, l):
	z1 = ary[0]
	x1 = - ary[2]+l
	y1 = ary[1]
	return np.array([x1,y1,z1]) 

def turn_scale(ary, l):
	return turn2(turn1(ary, l), l) * 4000 ##########

def makeFrame(Ppos, Wpos, num_particles, roomsize, num):
	# clear
    mlab.clf()
    #draw the bottom wall for timestep t
    p1 = turn_scale(Wpos[0,:], roomsize)	# bottom + front + left
    p4 = turn_scale(Wpos[3,:], roomsize)	# bottom + front + right
    x, y = np.mgrid[0: roomsize * 4000: 800j, 0: roomsize * 4000 :800j]
    z = y * (p4[2]-p1[2]) / (roomsize * 4000) + p1[2]
    mlab.mesh(x, y, z)

    #draw each particle for timestep t
    for p in range(num_particles):
    	print(Ppos[:,p])
    	Ppos[:,p] = turn_scale(Ppos[:,p], roomsize)
    mlab.points3d(Ppos[0,:], Ppos[1,:], Ppos[2,:], mode='sphere', resolution = 4, scale_factor = 10)  

    mlab.view(azimuth = 180, distance = 800, elevation = 70) # camera angle
    mlab.savefig("fig{}.png".format(num))

def makeVideo(movement_data, room, sim_size, fps):
	os.chdir("./fig")		#change the working directory

	movement_data_dim = movement_data.shape         
	num_particles = movement_data_dim[1]
	num_time_iterations = movement_data_dim[2]

	images_list = []
	fig_myv = mlab.figure(size = (sim_size, sim_size), bgcolor=(1,1,1))
	t = 0
	for n in range(num_time_iterations):
		bottomWall = room.get_wall(5, n)
		if n % 40 == 0:				# make a frame for every 40 steps
			images_list.append( makeFrame(movement_data[:,:,n], bottomWall, num_particles, room.get_room_size(), t) )
			t += 1
	mlab.clf()
	img_names = ['fig'+ str(i)+'.png' for i in range(t)]
	myclip = mpy.ImageSequenceClip(img_names, fps = fps)
	myclip.write_gif("vib_parts.gif", fps = fps) 		# 导出为GIF

	for n in range(t):				#delete the temporary files
		os.remove("fig{}.png".format(n))

