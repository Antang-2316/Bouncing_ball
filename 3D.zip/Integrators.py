import numpy as np

def exp_midpoint(y0, v0, f, N_steps, dt, room):
    tmp = 0
    agents_escaped = np.zeros(N_steps)
    
    y = np.zeros((y0.shape[0], y0.shape[1], N_steps))
    v = np.zeros((y0.shape[0], y0.shape[1], N_steps))
    a = np.zeros((y0.shape[0], y0.shape[1], N_steps))
    
    y[:,:,0] = y0

    for k in range(N_steps-1): # time
        a[:,:,k]   = f(y[:,:,:], v[:,:,:], k)
        v[:,:,k+1] = v[:,:,k] + dt*f(y[:,:,:] + 0.5*dt*v[:,:,:], v[:,:,:] + 0.5*dt*a[:,:,:], k)
        y[:,:,k+1] = y[:,:,k] + dt*v[:,:,k+1]
        # for()   #if the particles sink into the plane
        # {
        #     if()    
        #     {
        #         y = 
        #         v = 
        #         a = 
        #     }
        # }

    return y, a