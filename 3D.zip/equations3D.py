import numpy as np
from math import *

class Equations:
    def __init__(self, num_particles, L, h, room, radii, M, alpha, totaltime):
        self.room = room
        self.N = num_particles                      
        self.m = M                           
        self.radii = radii                         
        self.h = h                                  # time-step (s)
        self.L = L                                  # size of square room (m)
        self.K = 17
        self.miu_w = 0.95
        self.miu_p = 0.3
        self.g = 9.81
        self.tot = totaltime
        self.alpha = alpha
        self.numwalls = self.room.get_num_walls()   # number of walls 
        self.walls = self.room.walls_vib()          
        self.vib = self.room.vibration()
        self.vib1 = self.room.vibration1()
        self.vib2 = self.room.vibration2()     
        
    #Checks if a particle touches another one or a wall  
    def d(self, x):        
        if x < 0:
            return 0
        return x      
        
    def rad(self, i, j):  
        return self.radii[i] + self.radii[j]

    def wall_distance(self, i, j, r, v, k):                         # r[:,i,k] (time k, particle i)
        temp_wall      = self.walls[j,:,:,k]                        # wall j position at time k
        diag_vec1      = temp_wall[2,:]-temp_wall[0,:]              # diagnal vector
        diag_vec2      = temp_wall[3,:]-temp_wall[1,:]
        
        norm_vec       = np.cross(diag_vec2, diag_vec1)             # normal vector of wall j
        norm_unitvec   = norm_vec / np.linalg.norm(norm_vec)        # unit-normal vector
        pnt_vec        = r[:,i,k] - temp_wall[0,:] 
        dist           = np.dot(norm_unitvec, pnt_vec)              # the distance from the centre of the particle to the plane

        dv            = v[:, i, k] - v[:, i, k-1]
        if abs(dv < 1e-4).all():
            t = np.zeros(3) 
        else:
            dv_normvec    = np.dot(dv, norm_unitvec)
            temp_vec      = norm_unitvec * dv_normvec               #dv的法向投影向量
            temp_point    = v[:, i, k-1] + temp_vec
            t_vec         = v[:, i, k] - temp_point
            t             = t_vec / np.linalg.norm(t_vec)           # point to vk (end-point of dv)
        return dist, norm_unitvec, t   
    
    #Distance between particle i and j
    def particles_dist(self, i, j, r, v, k):                    # v = v[:,:,:]
        d             = np.linalg.norm(r[:, i, k] - r[:, j, k]) #at time k, distance between particles i and j
        n             = (r[:, i, k] - r[:, j, k])/d             #normal vector
        dv_i          = v[:, i, k] - v[:, i, k-1]
        dv_j          = v[:, j, k] - v[:, j, k-1]
        dv_ij         = dv_i - dv_j
        if abs(dv_ij < 1e-4).all():
            t = 0
        else:
            dv_normvec    = np.dot(dv_ij, n)
            temp_vec      = n * dv_normvec
            temp_point    = dv_j + temp_vec
            t_vec         = dv_i - temp_point
            t_len         = np.linalg.norm(t_vec)
            t             = t_vec / t_len                       # point to vk (end-point of dv) 
        return d, n, t
    
    #Force between particle i and j
    def f_ij(self, i, j, r, v, k):  
        d, n, t = self.particles_dist(i, j, r, v, k)
        rad_ij = self.rad(i, j)
        a = self.K * self.d(rad_ij - d)
        b = self.miu_p * a  
        return a * n + b * t
    
    def n(self, i, k): # time k
        if self.vib2[k] >= 9.81:
            return 0
        else:
            return self.m[i] * cos(self.alpha) * (self.g - self.vib2[k])

    def fr1(self, i, k): # time k
        return self.m[i] * sin(self.alpha) * (self.g - self.vib2[k])

    def fr2(self, i, k): # time k
        return -self.miu_w * self.n(i, k) * np.sign(-self.fr1(i, k))
    
    def f_iW(self, i, j, r, v, k):                                      # r = y[:,:,:] (time k, particle i)
        dist, per, t = self.wall_distance(i, j, r, v, k)
        fr = np.zeros((self.N, self.tot))
        a = self.K * self.d(self.radii[i] - dist) + self.n(i, k)
        if self.vib2[k] >= 9.81 or dist > self.radii[i]: 
            if dist <= self.radii[i]:
            #if r[1, i, k] >= (self.L - r[0, i, k] * tan(self.alpha)): # touch the bottom wall
                if abs(self.fr1(i, k)) >= self.miu_w * self.n(i, k):
                    fr[i,k] = self.fr2(i, k)
                else:
                    fr[i,k] = self.fr1(i, k)
            if dist > self.radii[i]: # not touch any wall
                fr[i,k] = 0
        else:
            if abs(self.fr1(i, k)) >= self.miu_w * self.n(i, k):
                fr[i,k] = self.fr2(i, k)
            else:
                fr[i,k] = self.fr1(i, k)
        
        return a * per - fr[i,k] * t 

    #The interacting force of the particles to each other  
    def f_particles(self, r, v, k):
        f_particles = np.zeros((3, self.N))
        fij     = np.zeros(((3, self.N, self.N)))
        for i in range(self.N-1):
            for j in range(self.N-1-i):
                    fij[:,i,j+i+1] = self.f_ij(i, j+i+1, r, v, k)
                    fij[:,j+i+1,i] = -fij[:,i,j+i+1]
        f_particles = np.sum(fij, 2) # total force for each pedestrian
        return f_particles

    #The force of each wall acting on each particles
    def f_wp(self, r, v, k):
        f_wall = np.zeros((3, self.N))
        for i in range(self.N):
            for j in range(self.numwalls):
                f_wall[:, i] += self.f_iW(i, j, r, v, k)
        return f_wall

    #Calculates the accelaration of each particle
    def f(self, r, v, k):
        a = np.zeros((3, self.N))
        a[1,:] = 1
        acc = self.f_particles(r, v, k) / self.m + self.f_wp(r, v, k) / self.m + self.g * a
        return acc

