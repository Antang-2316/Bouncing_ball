from Simulation3D import Simulation

sim = Simulation(num_particles = 50, num_steps = 1200, A = 0.001 * 0.017, alpha = 0.035 ,w = 180,
                 fai = 17, method = "exp_midpoint", room_size = 0.1)
sim.fill_room()                 		# fills the spawn zone with random particles
sim.run()                       		# runs the simulation
sim.show(sim_size = 400, fps = 8)
