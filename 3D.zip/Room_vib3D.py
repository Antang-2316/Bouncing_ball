import numpy as np
from math import *

class Room:
    def __init__(self, room_size, alpha, A, w, fai, totaltime, h):
        print("正在初始化容器……")
        self.room_size = room_size # length
        self.A = A
        self.w = w
        self.fai = fai
        self.tot = totaltime
        self.h = h
        self.alpha = alpha
        self.num_walls = 6
        self.slope = self.room_size * (1 - tan(self.alpha))
        p1 = [0, 0, 0]                                      # top + front + left
        p2 = [0, self.room_size, 0]                         # bottom + front + left
        p3 = [self.room_size, self.slope, 0]                # bottom + front + right
        p4 = [self.room_size, 0, 0]                         # top + front + right
        p5 = [0, 0, self.room_size]                         # top + back + left
        p6 = [0, self.room_size, self.room_size]            # bottom + back + left
        p7 = [self.room_size, self.slope, self.room_size]   # bottom + back + right
        p8 = [self.room_size, 0, self.room_size]            # top + back + right

        self.walls = np.array([[p1, p2, p3, p4],        # front wall 0
                        [p4, p3, p7, p8],               # right wall 1
                        [p8, p7, p6, p5],               # back wall 2
                        [p5, p6, p2, p1],               # left wall 3
                        [p5, p1, p4, p8],               # top wall 4
                        [p2, p6, p7, p3]])              # bottom wall 5
                        
        self.spawn_zone = np.array([self.room_size*0.01, self.room_size *0.99]) 
        #range of x and z, particles generated on a plane parallel to the slope

        print("容器初始化完成")

    def vib(self, t):
        return self.A * sin(self.w * t - self.fai)

    def vibration(self):
        vibration = np.zeros(self.tot)
        time = np.arange(1, self.tot+1) * self.h
        for i in range(self.tot):
            vibration[i] = self.vib(time[i])
        return vibration
    
    def vib1(self, t):
        return self.A * self.w * cos(self.w * t - self.fai)

    def vibration1(self):
        vibration1 = np.zeros(self.tot)
        time = np.arange(1, self.tot+1)*self.h
        for i in range(self.tot):
            vibration1[i] = self.vib1(time[i])
        return vibration1
    
    def vib2(self, t):
        return (- (self.w ** 2)) * self.vib(t)

    def vibration2(self):
        vibration2 = np.zeros(self.tot)
        time = np.arange(1, self.tot+1) * self.h
        for i in range(self.tot):
            vibration2[i] = self.vib2(time[i])
        return vibration2

    def walls_vib(self):
        time = np.arange(1, self.tot+ 1)*self.h
        wall_vib = np.zeros((6, 4, 3, self.tot))
        zero = np.zeros(self.tot)
        for n in range(self.tot):
            if n <= 8:
                wall_vib[:,:,:,n] = self.walls * (1 + zero[n])
            else:
                curr = np.array([1, 1 + self.vib(time[n]), 1])
                for i in range(6):
                    for j in range(4):
                        wall_vib[i,j,:,n] = self.walls[i,j] * curr
        return wall_vib
                                         
    def get_wall(self, n, k):               # gives back the endpoints of the nth wall
        return self.walls_vib()[n,:,:,k]

    def get_alpha(self):              # gives back the endpoints of the nth wall
        return self.alpha

    def get_wall_front(self, n, k):
        return (self.walls_vib()[n,:,0,k], self.walls_vib()[n,:,1,k])

    def get_num_walls(self):            # gives back the number of walls
        return self.num_walls

    def get_spawn_zone(self):            # gives back the spawn_zone
        return self.spawn_zone

    def get_room_size(self):            # gives back the size of the room
        return self.room_size

