import numpy as np
import sys
from equations import Equations
import pygame
from steps_function_quit import display_events
from Room_vib import Room
import Integrators

class Simulation:
    def __init__(self, num_particles, num_steps, alpha, A, w, phi, room_size, method = "exp_midpoint", tau = 0.02):

        self.L = room_size                  # size of square room (m)
        self.N = num_particles              # quantity of particles
        self.tau = tau                      # time-step (s)
        self.num_steps = num_steps          # number of steps for integration
        self.A = A
        self.w = w
        self.alpha = alpha
        self.phi = phi
        # Particle information
        self.radii = 5 * np.ones(self.N)                # radii of particles (m)
        self.m = 80 * np.ones(self.N)                   # mass of particles (kg)
        self.v_0 = np.zeros(self.N)                     # desired velocity (m/s)
        self.forces = None                              # forces on the particles
        self.v = np.zeros((2, self.N, self.num_steps))  # Three dimensional array of velocity
        self.y = np.zeros((2, self.N, self.num_steps))  # Three dimensional array of place: x = coordinates, y = particle, z=Time
        
        # other
        self.room = Room(self.L, self.alpha, self.A, self.w, self.phi, self.num_steps, tau)  # kind of room the simulation runs in
        self.method = getattr(Integrators, method)  # method used for integration
        self.equ = Equations(self.N, self.L, self.tau, self.room, self.radii, self.m, self.alpha, self.num_steps)  # initialize Differential equation
 
    # function set_time, set_steps give the possiblity to late change these variable when needed
    def set_steps(self, steps):
        self.num_steps = steps

    # function to change the methode of integration if needed
    def set_methode(self, method):
        self.method = getattr(Integrators, method)

    # yields false if particles don't touch each other and true if they do
    def dont_touch(self, i, pos): 
        for j in range(i - 1):
            if np.linalg.norm(np.array(pos) - self.y[:, j, 0]) < 3 * self.radii[i]:
                return True
        return False

    # fills the spawn zone with particles with random positions
    def fill_room(self):
        spawn = self.room.get_spawn_zone()
        len_width = spawn[0, 1] - spawn[0, 0]
        len_height = spawn[1, 1] - spawn[1, 0]
        max_len = max(len_height, len_width)

        # checks if the area is too small for the particles to fit in
        area_particle = 0
        for i in range(self.N):
            area_particle += 4 * self.radii[i] ** 2
        if area_particle >= 0.7 * max_len ** 2:
            sys.exit('Too much particles! ')
        # checks if the particle touches another particle/wall and if so gives it a new random position in the spawn-zone 
        for i in range(self.N):
            # The particle don't touch the wall
            x = len_width * np.random.rand() + spawn[0, 0]
            y = len_height * np.random.rand() + spawn[1, 0]
            pos = [x, y]

            # The particles don't touch each other
            while self.dont_touch(i, pos):#touch is true, change x,y coordinate
                x = len_width * np.random.rand() + spawn[0, 0]
                y = len_height * np.random.rand() + spawn[1, 0]
                pos = [x, y]
            self.y[:, i, 0] = pos

        self.v[:, :, 0] = self.v_0

    # calls the method of integration with the starting positions, diffequatial equation, number of steps, and delta t = tau
    def run(self):
        self.y, self.forces = self.method(self.y[:, :, 0], self.v[:, :, 0], self.equ.f, self.num_steps, self.tau, self.room)

    # Displays the simulation in pygame
    def show(self, wait_time, sim_size):
        display_events(self.y, self.room, wait_time, self.radii, sim_size)