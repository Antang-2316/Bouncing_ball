import numpy as np
from math import *

class Room:
    def __init__(self, room_size, alpha, A, w, phi, totaltime, h):
        self.room_size = room_size # length
        self.A = A
        self.w = w
        self.phi = phi
        self.tot = totaltime
        self.h = h
        self.alpha = alpha
        self.num_walls = 4
        self.walls = np.array([[[1, 1], [1, self.room_size]],                                               # left wall
                        [[1, self.room_size], [self.room_size, self.room_size * (1 - tan(self.alpha))]],    # bottom wall
                        [[self.room_size, self.room_size * (1 - tan(self.alpha))], [self.room_size, 1]],    # right wall
                        [[self.room_size, 1], [1, 1]]])                                                     # top wall
        self.spawn_zone = np.array([[10, self.room_size -10], [self.room_size - 30, self.room_size - 10]])  
    
    def vib(self, t):
        return self.A * sin(self.w * t - self.phi)

    def vibration(self):
        vibration = np.zeros(self.tot)
        time = np.arange(1, self.tot+1) * self.h
        for i in range(self.tot):
            vibration[i] = self.vib(time[i])
        return vibration
    
    def vib1(self, t):
        return self.A * self.w * cos(self.w * t - self.phi)

    def vibration1(self):
        vibration1 = np.zeros(self.tot)
        time = np.arange(1, self.tot+1) * self.h
        for i in range(self.tot):
            vibration1[i] = self.vib1(time[i])
        return vibration1
    
    def vib2(self, t):
        return (- (self.w ** 2)) * self.vib(t)

    def vibration2(self):
        vibration2 = np.zeros(self.tot)
        time = np.arange(1, self.tot+1) * self.h
        for i in range(self.tot):
            vibration2[i] = self.vib2(time[i])
        return vibration2

    def walls_vib(self):
        time = np.arange(1, self.tot+1) * self.h
        wall_vib = np.zeros((4,2,2,self.tot))
        zero = np.zeros(self.tot)
        for i in range(self.tot):
            if i <= self.tot / 8:
                wall_vib[:,:,:,i] = self.walls * (1 + zero[i])
            else:
                wall_vib[:,:,:,i] = self.walls * (1 + self.vib(time[i]))
        return wall_vib
                                         
    def get_wall(self, n, k):              # gives back the endpoints of the nth wall
        return self.walls_vib()[n,:,:, k]

    def get_num_walls(self):            # gives back the number of walls
        return self.num_walls

    def get_spawn_zone(self):            # gives back the spawn_zone
        return self.spawn_zone

    def get_room_size(self):            # gives back the size of the room
        return self.room_size

