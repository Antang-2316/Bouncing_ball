import numpy as np
import pygame
import matplotlib.pyplot as plt

def display_events(movement_data, room, wait_time, radii, sim_size):

    # colors
    background_color = (170, 170, 170)            #grey
    people_color = (250, 0, 0)                    #red
    object_color = (0, 0, 0)                      #black

    # variable for initializing pygame
    normalizer = int(sim_size/room.get_room_size())     # the ratio (size of image) / (size of actual room) 
    map_size = (room.get_room_size()*normalizer + 100,  #size of the map
                room.get_room_size()*normalizer + 100)  #plus a little free space
    wait_time = wait_time                               #time that the simultation waits between each timestep
    wait_time_after_sim = 1000  # 3s                    #waittime after simulation
    movement_data_dim = movement_data.shape         
    num_particles = movement_data_dim[1]          #number of indiciduals in the simulation
    num_time_iterations = movement_data_dim[2]  #number of timesteps
    num_walls = room.get_num_walls()            #number of walls

    pygame.init()                                 #initialize the intanz
    simulate=False                                #variable to indicate if the simulation is running
    font = pygame.font.Font(None, 32)             #create a new object of type Font(filename, size)
    worldmap = pygame.display.set_mode(map_size)
    
    while True:
        # start simulation if any key is pressed and quits pygame if told so
        for event in pygame.event.get(): 
            if event.type == pygame.KEYDOWN:
                simulate=True
                if event.key == pygame.K_0:
                    pygame.quit()
            elif event.type == pygame.QUIT:
                pygame.quit()
        worldmap.fill(0) # black
        #This creates a new surface with text already drawn onto it
        text = font.render('Press any key to start , Press 0 to quit', True, (255, 255, 255))
        #printing the text starting with a 'distance' of (100,100) from top left
        worldmap.blit(text, (10, 100))
        pygame.display.update()
        
        if simulate == True:
            # print the map for each timestep
            for t in range(num_time_iterations): # number of time step
                # quit the simulation if told so
                for event in pygame.event.get():
                    if event.type == pygame.QUIT:
                        pygame.quit()
                
                #initialize the map with background color
                worldmap.fill(background_color)
        
                #draw each particle for timestep t
                for particle in range(num_particles):
                    pygame.draw.circle(worldmap, people_color, 
                                    ((normalizer*movement_data[0, particle, t] + 50).astype(int),
                                    (normalizer*movement_data[1, particle, t] + 50).astype(int)),
                                    int(normalizer * radii[particle]), 0)
        
                #draw each object for timestep t
                for wall in range(num_walls):
                    pygame.draw.lines(worldmap, object_color, True, 
                                    normalizer * room.get_wall(wall, t) + 50, 2)

                #update the map
                pygame.display.update()
                #wait for a while before drawing new positions
                pygame.time.wait(wait_time)
            simulate=False
            text = font.render('SIMULATION FINISHED', True, (0, 255, 0))
            worldmap.blit(text, (100, 90))
            pygame.display.update()
            pygame.time.wait(wait_time_after_sim)


