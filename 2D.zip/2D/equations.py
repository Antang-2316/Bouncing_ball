import numpy as np
from math import *

class Equations:
    def __init__(self, num_particles, L, h, room, radii, M, alpha, totaltime):
        self.room = room                            #import class room as room
        self.N = num_particles                      
        self.m = M                           
        self.radii = radii                         
        self.h = h                              # time-step (s)
        self.L = L                                  # size of square room (m)
        self.K = 10000
        self.miu_w = 0.7
        self.miu_p = 0.1
        self.g = 9.81
        self.tot = totaltime
        self.alpha = alpha
        self.numwalls = self.room.get_num_walls()   # number of walls 
        self.walls = self.room.walls_vib()          
        self.vib = self.room.vibration()
        self.vib1 = self.room.vibration1()
        self.vib2 = self.room.vibration2()


    def walls(self, t):
        return self.room.walls_vib(t)      
        
    #Checks if a particle touches anotherone or a wall  
    def d(self, x):        
        if x < 0:
            return 0
        else:
            return x      
        
    def rad(self, i, j):  
        return self.radii[i] + self.radii[j]

    #Distance between particle i at positon r and wall j
    def wall_distance(self, i, j, r, k): 
        temp_wall      = self.walls[j,:,:,k] # wall j position at time k
        line_vec       = temp_wall[1,:]-temp_wall[0,:] # distth of wall j  [len_x, len_y]
        pnt_vec        = r[:,i,k]-temp_wall[0,:] # at time k, [len_x_i-wall j.startpoint, len_y_i-wall j.startpoint]
        line_len       = np.linalg.norm(line_vec) # distth of wall j
        line_unitvec   = line_vec / line_len # norm(line_unitvec) = 1
        pnt_vec_scaled = pnt_vec / line_len
        temp           = line_unitvec.dot(pnt_vec_scaled)    
        if temp < 0.0:
            temp = 0.0
        elif temp > 1.0:
            temp = 1.0
        nearest       = line_vec * temp
        dist          = pnt_vec - nearest
        nearest       = nearest + temp_wall[0,:]
        distance      = np.linalg.norm(dist)
        per           = dist / distance
        t             = np.array([-per[1], per[0]])
        return distance, per, t, nearest   
    
    #Distance between particle i and  j
    def particles_dist(self, i, j, r, v, k): # v = v[:,:,:]
        d    = np.linalg.norm(r[:, i, k] - r[:, j, k]) #at time k, distance between pedestrian i and j
        n    = (r[:, i, k] - r[:, j, k])/d
        t    = np.array([-n[1],n[0]]) # norm = 1
        return d, n, t
    
    #Force between particle i and j
    def f_ij(self, i, j, r, v, k):  
        d, n, t = self.particles_dist(i, j, r, v, k)
        rad_ij = self.rad(i, j)
        a = self.K * self.d(rad_ij - d)
        b = self.miu_p * a  
        return a * n + b * t
    
    def n(self, i, k): # time k
        if self.vib2[k] >= 9.81:
            return 0
        else:
            return self.m[i] * cos(self.alpha) * (self.g - self.vib2[k])

    '''def support(self, k):
        a = np.arange([0, -1])
        return self.n(k) * a'''

    def fr1(self, i, k): # time k
        return self.m[i] * sin(self.alpha) * (self.g - self.vib2[k])

    def fr2(self, i, k): # time k
        return -self.miu_w * self.n(i, k) * np.sign(-self.fr1(i, k))

    '''def heigth(self, v, i, k): # v = v[:,:,k], v[:,i] = v[:,i,k] time k
        return 0.5 * (- self.g * cos(self.alpha)) * self.h**2 - \
            (self.vib[k]-self.vib[k-1]) * cos(self.alpha) + v[:, i, k] * self.h'''
    
    def f_iW(self, i, j, r, v, k): # r = y[:,:,:] (time k, particle i)
        dist, per, t, nearest = self.wall_distance(i, j, r, k)
        fr = np.zeros((self.N, self.tot))
        #a = np.zeros((self.N, self.tot))
        a = self.K * self.d(self.radii[i] - dist) + self.n(i, k)
        if self.vib2[k] >= 9.81 or dist > self.radii[i]: 
            if dist <= self.radii[i]:
            #if r[1, i, k] >= (self.L - r[0, i, k] * tan(self.alpha)): # touch the bottom wall
                if abs(self.fr1(i, k)) >= self.miu_w * self.n(i, k):
                    fr[i,k] = self.fr2(i, k)
                else:
                    fr[i,k] = self.fr1(i, k)
            if dist > self.radii[i]: # not touch any wall
                fr[i,k] = 0
        else:
            if abs(self.fr1(i, k)) >= self.miu_w * self.n(i, k):
                fr[i,k] = self.fr2(i, k)
            else:
                fr[i,k] = self.fr1(i, k)
        
        return a * per - fr[i,k] * t ### check the direction of fr

    #The interacting force of the particles to each other  
    def f_particles(self, r, v, k):
        f_particles = np.zeros((2, self.N))
        fij     = np.zeros(((2, self.N, self.N)))
        for i in range(self.N-1):
            for j in range(self.N-1-i):
                    fij[:,i,j+i+1] = self.f_ij(i, j+i+1, r, v, k)
                    fij[:,j+i+1,i] = -fij[:,i,j+i+1]
        f_particles = np.sum(fij, 2) # total force for each pedestrian
        return f_particles

    #The force of each wall acting on each particles
    def f_wp(self, r, v, k):
        f_wall = np.zeros((2, self.N))
        for i in range(self.N):
            for j in range(self.numwalls):
                f_wall[:, i] += self.f_iW(i, j, r, v, k)
        return f_wall

    '''#The interacting force of the particles to each other  
    def f_particles(self, r, v, k):
        f_particles = np.zeros((2, self.N, self.tot))
        fij     = np.zeros(((2, self.N, self.N, self.tot)))
        for i in range(self.N-1):
            for j in range(self.N-1-i):
                    fij[:,i,j+i+1,k] = self.f_ij(i, j+i+1, r, v, k)
                    fij[:,j+i+1,i,k] = -fij[:,i,j+i+1, k]
        f_particles = np.sum(fij, 2) # total force for each pedestrian
        return f_particles

    #The force of each wall acting on each particles
    def f_wp(self, r, v, k):
        f_wall = np.zeros((2, self.N, self.tot))
        for i in range(self.N):
            for j in range(self.numwalls):
                f_wall[:, i, k] += self.f_iW(i, j, r, v, k)
        return f_wall'''

    #Calculates the accelaration of each particle
    def f(self, r, v, k):########
        a = np.zeros((2, self.N))
        a[1,:] = 1
        acc = self.f_particles(r, v, k) / self.m + self.f_wp(r, v, k) / self.m + self.g * a
        return acc

