
from Simulation import Simulation

sim = Simulation(num_particles=10, num_steps=500, A = 0.005, alpha = 0.01 ,w = 40,phi = 10, method="exp_midpoint", room_size=400)
sim.fill_room()                 # fills the spawn zone with random people
sim.run()                       # runs the simulation
sim.show(wait_time=50, sim_size=600)   # displays the solutions to the simulations in pygame with
